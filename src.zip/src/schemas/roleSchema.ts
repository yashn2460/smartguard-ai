import Joi from 'joi';
import { RoleType } from '../models/Role';

export const createRoleSchema = Joi.object({
  name: Joi.string().valid(...Object.values(RoleType)).required(),
  description: Joi.string().required().trim(),
  permissions: Joi.array().items(Joi.string().trim()).required()
});

export const updateRoleSchema = Joi.object({
  description: Joi.string().trim(),
  permissions: Joi.array().items(Joi.string().trim())
}); 