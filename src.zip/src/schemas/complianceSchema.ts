import Joi from 'joi';
import { ComplianceStatus } from '../models/ComplianceCheck';

export const createComplianceCheckSchema = Joi.object({
  regulationName: Joi.string().required().trim(),
  requirement: Joi.string().required().trim(),
  facilityId: Joi.string().required().hex().length(24),
  status: Joi.string().valid(...Object.values(ComplianceStatus)),
  notes: Joi.string().trim()
});

export const updateComplianceCheckSchema = Joi.object({
  regulationName: Joi.string().trim(),
  requirement: Joi.string().trim(),
  facilityId: Joi.string().hex().length(24),
  status: Joi.string().valid(...Object.values(ComplianceStatus)),
  notes: Joi.string().trim()
}); 