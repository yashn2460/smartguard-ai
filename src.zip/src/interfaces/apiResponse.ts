export interface ApiResponse {
  success: boolean;
  data?: any;
  error?: string;
  message: string;
  statusCode: number;
} 