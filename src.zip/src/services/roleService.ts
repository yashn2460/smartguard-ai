import { Role, IRole, RoleType } from '../models/Role';
import { ApiError } from '../utils/apiError';

export class RoleService {
  /**
   * Get all roles
   */
  public async getRoles(): Promise<IRole[]> {
    return Role.find();
  }

  /**
   * Get a role by name
   * @param name Role name
   */
  public async getRoleByName(name: RoleType): Promise<IRole> {
    const role = await Role.findOne({ name });
    
    if (!role) {
      throw new ApiError('Role not found', 404);
    }
    
    return role;
  }

  /**
   * Create a new role
   * @param data Role data
   */
  public async createRole(data: {
    name: RoleType;
    description: string;
    permissions: string[];
  }): Promise<IRole> {
    // Check if role already exists
    const existingRole = await Role.findOne({ name: data.name });
    
    if (existingRole) {
      throw new ApiError('Role already exists', 400);
    }
    
    const role = new Role(data);
    await role.save();
    
    return role;
  }

  /**
   * Update a role
   * @param name Role name
   * @param data Update data
   */
  public async updateRole(
    name: RoleType,
    data: {
      description?: string;
      permissions?: string[];
    }
  ): Promise<IRole> {
    const role = await Role.findOne({ name });
    
    if (!role) {
      throw new ApiError('Role not found', 404);
    }
    
    // Update fields
    if (data.description) role.description = data.description;
    if (data.permissions) role.permissions = data.permissions;
    
    await role.save();
    return role;
  }

  /**
   * Delete a role
   * @param name Role name
   */
  public async deleteRole(name: RoleType): Promise<void> {
    const result = await Role.findOneAndDelete({ name });
    
    if (!result) {
      throw new ApiError('Role not found', 404);
    }
  }

  /**
   * Initialize default roles if they don't exist
   */
  public async initializeDefaultRoles(): Promise<void> {
    const defaultRoles = [
      {
        name: RoleType.ADMIN,
        description: 'Administrator with full access to all features',
        permissions: ['all']
      },
      {
        name: RoleType.COMPLIANCE_OFFICER,
        description: 'Officer responsible for compliance checks and reporting',
        permissions: ['manage_compliance', 'view_reports', 'manage_facilities']
      },
      {
        name: RoleType.AUDITOR,
        description: 'Auditor who reviews compliance reports and findings',
        permissions: ['view_compliance', 'view_reports', 'create_audit_reports']
      },
      {
        name: RoleType.FACILITY_MANAGER,
        description: 'Manager of a specific facility',
        permissions: ['view_facility', 'update_facility', 'view_compliance']
      },
      {
        name: RoleType.USER,
        description: 'Regular user with limited access',
        permissions: ['view_own_profile', 'update_own_profile']
      }
    ];

    for (const roleData of defaultRoles) {
      const existingRole = await Role.findOne({ name: roleData.name });
      
      if (!existingRole) {
        await this.createRole(roleData);
      }
    }
  }
} 