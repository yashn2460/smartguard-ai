import { Auth, IAuth } from '../models/Auth';
import { User, IUser } from '../models/User';
import jwt from 'jsonwebtoken';
import { ApiError } from '../utils/apiError';
import { Types } from 'mongoose';
import { EmailService } from './emailService';
import { RoleType } from '../models/Role';

export class AuthService {
  private emailService: EmailService;

  constructor() {
    this.emailService = new EmailService();
  }

  private generateToken(userId: string, role: RoleType): string {
    const secret = process.env.JWT_SECRET || 'your_jwt_secret_key_here';
    const expiresIn = process.env.JWT_EXPIRES_IN || '24h';
    
    return jwt.sign({ userId, role }, secret, { expiresIn: expiresIn as jwt.SignOptions['expiresIn'] });
  }

  public async register(userData: { email: string; password: string; name: string }): Promise<{ user: IUser; token: string }> {
    // Check if user already exists
    const existingAuth = await Auth.findOne({ email: userData.email });
    if (existingAuth) {
      throw new ApiError('Email already registered', 400);
    }

    // Create user 
    const user = new User({
       name: userData.name ,
       email: userData.email,
       role: RoleType.COMPLIANCE_OFFICER,
       password: userData.password
    });
    await user.save();

    // Create auth
    const auth = new Auth({
      email: userData.email,
      password: userData.password,
      userId: user._id
    });
    await auth.save();

    // Generate and send verification code
    const verificationCode = await auth.generateVerificationCode();
    await this.emailService.sendVerificationCode(userData.email, verificationCode);

    // Generate token
    const token = this.generateToken((user._id as Types.ObjectId).toString(), user.role);

    return { user, token };
  }

  public async login(email: string, password: string): Promise<{ user: IUser; token: string }> {
    // Find auth by email
    const auth = await Auth.findOne({ email }).populate('userId');
    if (!auth) {
      throw new ApiError('Invalid credentials', 401);
    }

    // Check password
    const isPasswordValid = await auth.comparePassword(password);
    if (!isPasswordValid) {
      throw new ApiError('Invalid credentials', 401);
    }

    // Check if user is verified
    if (!auth.isVerified) {
      // Generate and send a new verification code
      const verificationCode = await auth.generateVerificationCode();
      await this.emailService.sendVerificationCode(email, verificationCode);
      
      throw new ApiError('Email not verified. A new verification code has been sent.', 403);
    }

    // Get user
    const user = await User.findById(auth.userId);
    if (!user) {
      throw new ApiError('User not found', 404);
    }

    // Generate token
    const token = this.generateToken((user._id as Types.ObjectId).toString(), user.role);

    return { user, token };
  }

  public async verifyEmail(email: string, code: string): Promise<{ success: boolean }> {
    // Find auth by email
    const auth = await Auth.findOne({ email });
    if (!auth) {
      throw new ApiError('User not found', 404);
    }

    // Check if already verified
    if (auth.isVerified) {
      return { success: true };
    }

    // Check if verification code exists and is valid
    if (!auth.verificationCode || !auth.verificationCodeExpires) {
      throw new ApiError('No verification code found. Please request a new one.', 400);
    }

    // Check if verification code is expired
    if (auth.verificationCodeExpires < new Date()) {
      throw new ApiError('Verification code has expired. Please request a new one.', 400);
    }

    // Check if verification code matches
    if (auth.verificationCode !== code) {
      throw new ApiError('Invalid verification code', 400);
    }

    // Mark as verified
    auth.isVerified = true;
    auth.verificationCode = null;
    auth.verificationCodeExpires = null;
    await auth.save();

    return { success: true };
  }

  public async resendVerificationCode(email: string): Promise<{ success: boolean }> {
    // Find auth by email
    const auth = await Auth.findOne({ email });
    if (!auth) {
      throw new ApiError('User not found', 404);
    }

    // Check if already verified
    if (auth.isVerified) {
      return { success: true };
    }

    // Generate and send a new verification code
    const verificationCode = await auth.generateVerificationCode();
    await this.emailService.sendVerificationCode(email, verificationCode);

    return { success: true };
  }
} 