import { ComplianceCheck, IComplianceCheck, ComplianceStatus } from '../models/ComplianceCheck';
import { ApiError } from '../utils/apiError';
import { Types } from 'mongoose';

export class ComplianceService {
  /**
   * Get all compliance checks
   * @param facilityId Optional facility ID to filter by
   */
  public async getComplianceChecks(facilityId?: string): Promise<IComplianceCheck[]> {
    const query: any = {};
    
    if (facilityId) {
      query.facilityId = new Types.ObjectId(facilityId);
    }
    
    return ComplianceCheck.find(query).populate('facilityId');
  }

  /**
   * Get a compliance check by ID
   * @param id Compliance check ID
   */
  public async getComplianceCheckById(id: string): Promise<IComplianceCheck> {
    const complianceCheck = await ComplianceCheck.findById(id).populate('facilityId');
    
    if (!complianceCheck) {
      throw new ApiError('Compliance check not found', 404);
    }
    
    return complianceCheck;
  }

  /**
   * Create a new compliance check
   * @param data Compliance check data
   */
  public async createComplianceCheck(data: {
    regulationName: string;
    requirement: string;
    facilityId: string;
    status?: ComplianceStatus;
    notes?: string;
  }): Promise<IComplianceCheck> {
    // Validate facility ID
    if (!Types.ObjectId.isValid(data.facilityId)) {
      throw new ApiError('Invalid facility ID', 400);
    }
    
    const complianceCheck = new ComplianceCheck({
      ...data,
      facilityId: new Types.ObjectId(data.facilityId),
      lastCheckedDate: new Date(),
    });
    
    await complianceCheck.save();
    return complianceCheck.populate('facilityId');
  }

  /**
   * Update a compliance check
   * @param id Compliance check ID
   * @param data Update data
   */
  public async updateComplianceCheck(
    id: string,
    data: {
      regulationName?: string;
      requirement?: string;
      facilityId?: string;
      status?: ComplianceStatus;
      notes?: string;
    }
  ): Promise<IComplianceCheck> {
    const complianceCheck = await ComplianceCheck.findById(id);
    
    if (!complianceCheck) {
      throw new ApiError('Compliance check not found', 404);
    }
    
    // Validate facility ID if provided
    if (data.facilityId && !Types.ObjectId.isValid(data.facilityId)) {
      throw new ApiError('Invalid facility ID', 400);
    }
    
    // Update fields
    if (data.regulationName) complianceCheck.regulationName = data.regulationName;
    if (data.requirement) complianceCheck.requirement = data.requirement;
    if (data.facilityId) complianceCheck.facilityId = new Types.ObjectId(data.facilityId);
    if (data.status) complianceCheck.status = data.status;
    if (data.notes !== undefined) complianceCheck.notes = data.notes;
    
    // Update last checked date
    complianceCheck.lastCheckedDate = new Date();
    
    await complianceCheck.save();
    return complianceCheck.populate('facilityId');
  }

  /**
   * Delete a compliance check
   * @param id Compliance check ID
   */
  public async deleteComplianceCheck(id: string): Promise<void> {
    const result = await ComplianceCheck.findByIdAndDelete(id);
    
    if (!result) {
      throw new ApiError('Compliance check not found', 404);
    }
  }
} 