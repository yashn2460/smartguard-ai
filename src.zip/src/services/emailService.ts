import { MailerSend, EmailParams, Sender, Recipient } from 'mailersend';

/**
 * Email service for sending verification codes using MailerSend
 */
export class EmailService {
  private mailerSend: MailerSend;
  private fromEmail: string;
  private fromName: string;

  constructor() {
    this.mailerSend = new MailerSend({
      apiKey: process.env.MAILERSEND_API_KEY || 'mlsn.bb37900c4389ccb35c0921e1c5d453b56607d1831e9fba77eb9615f28fc8baf5',
    });
    this.fromEmail = process.env.MAILERSEND_FROM_EMAIL || 'noreply@trial-dnvo4d97k99g5r86.mlsender.net';
    this.fromName = process.env.MAILERSEND_FROM_NAME || 'SmartGuard AI';
  }

  /**
   * Send verification code to user's email
   * @param email User's email address
   * @param code Verification code
   */
  public async sendVerificationCode(email: string, code: string): Promise<void> {
    try {
      const sentFrom = new Sender(this.fromEmail, this.fromName);
      const recipients = [new Recipient(email)];

      const emailParams = new EmailParams()
        .setFrom(sentFrom)
        .setTo(recipients)
        .setSubject('Verify your email - SmartGuard AI')
        .setHtml(`
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #333;">Email Verification</h2>
            <p>Thank you for registering with SmartGuard AI. Please use the verification code below to verify your email address:</p>
            <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; text-align: center; margin: 20px 0;">
              <h1 style="color: #4a6cf7; margin: 0; letter-spacing: 5px;">${code}</h1>
            </div>
            <p>This code will expire in 15 minutes.</p>
            <p>If you did not request this verification, please ignore this email.</p>
            <p>Best regards,<br>The SmartGuard AI Team</p>
          </div>
        `)
        .setText(`Your verification code is: ${code}\n\nThis code will expire in 15 minutes.`);

      await this.mailerSend.email.send(emailParams);
      console.log(`Verification code ${code} sent to ${email} via MailerSend`);
    } catch (error) {
      console.error('Failed to send verification email:', error);
      // In a production environment, you might want to use a proper logging service
      // or handle this error differently
    }
  }

  /**
   * Send password reset code to user's email
   * @param email User's email address
   * @param code Reset code
   */
  public async sendPasswordResetCode(email: string, code: string): Promise<void> {
    try {
      const sentFrom = new Sender(this.fromEmail, this.fromName);
      const recipients = [new Recipient(email)];

      const emailParams = new EmailParams()
        .setFrom(sentFrom)
        .setTo(recipients)
        .setSubject('Reset your password - SmartGuard AI')
        .setHtml(`
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #333;">Password Reset</h2>
            <p>You have requested to reset your password for your SmartGuard AI account. Please use the code below to reset your password:</p>
            <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; text-align: center; margin: 20px 0;">
              <h1 style="color: #4a6cf7; margin: 0; letter-spacing: 5px;">${code}</h1>
            </div>
            <p>This code will expire in 15 minutes.</p>
            <p>If you did not request a password reset, please ignore this email or contact support if you have concerns.</p>
            <p>Best regards,<br>The SmartGuard AI Team</p>
          </div>
        `)
        .setText(`Your password reset code is: ${code}\n\nThis code will expire in 15 minutes.`);

      await this.mailerSend.email.send(emailParams);
      console.log(`Password reset code ${code} sent to ${email} via MailerSend`);
    } catch (error) {
      console.error('Failed to send password reset email:', error);
      // In a production environment, you might want to use a proper logging service
      // or handle this error differently
    }
  }
} 