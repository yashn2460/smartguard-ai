import { User, IUser } from '../models/User';

export class UserService {
  public async createUser(userData: Partial<IUser>): Promise<IUser> {
    const user = new User(userData);
    return await user.save();
  }

  public async getUsers(): Promise<IUser[]> {
    return await User.find().sort({ createdAt: -1 });
  }

  public async getUserById(id: string): Promise<IUser | null> {
    return await User.findById(id);
  }

  public async updateUser(id: string, userData: Partial<IUser>): Promise<IUser | null> {
    return await User.findByIdAndUpdate(id, userData, { new: true });
  }

  public async deleteUser(id: string): Promise<IUser | null> {
    return await User.findByIdAndDelete(id);
  }
} 