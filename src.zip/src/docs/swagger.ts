import swaggerJsdoc from 'swagger-jsdoc';

const options: swaggerJsdoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'SmartGuard AI API',
      version: '1.0.0',
      description: 'API documentation for SmartGuard AI backend',
      contact: {
        name: 'SmartGuard AI Team',
        email: 'support@smartguard.ai'
      }
    },
    servers: [
      {
        url: 'http://localhost:3000/api/v1',
        description: 'Development server'
      }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT'
        }
      },
      schemas: {
        User: {
          type: 'object',
          properties: {
            _id: {
              type: 'string',
              description: 'User ID'
            },
            name: {
              type: 'string',
              description: 'User name'
            },
            email: {
              type: 'string',
              description: 'User email'
            },
            role: {
              type: 'string',
              enum: ['admin', 'compliance_officer', 'auditor', 'facility_manager', 'user'],
              description: 'User role'
            },
            isEmailVerified: {
              type: 'boolean',
              description: 'Whether the user email is verified'
            },
            createdAt: {
              type: 'string',
              format: 'date-time',
              description: 'User creation date'
            },
            updatedAt: {
              type: 'string',
              format: 'date-time',
              description: 'User last update date'
            }
          }
        },
        AuthResponse: {
          type: 'object',
          properties: {
            user: {
              $ref: '#/components/schemas/User'
            },
            token: {
              type: 'string',
              description: 'JWT token'
            }
          }
        },
        VerificationResponse: {
          type: 'object',
          properties: {
            success: {
              type: 'boolean',
              description: 'Verification success status'
            }
          }
        },
        ApiResponse: {
          type: 'object',
          properties: {
            success: {
              type: 'boolean',
              description: 'Operation success status'
            },
            data: {
              type: 'object',
              description: 'Response data'
            },
            message: {
              type: 'string',
              description: 'Response message'
            },
            error: {
              type: 'string',
              description: 'Error message (if any)'
            }
          }
        },
        Facility: {
          type: 'object',
          properties: {
            _id: {
              type: 'string',
              description: 'Facility ID'
            },
            name: {
              type: 'string',
              description: 'Facility name'
            },
            address: {
              type: 'string',
              description: 'Facility address'
            },
            city: {
              type: 'string',
              description: 'City'
            },
            state: {
              type: 'string',
              description: 'State'
            },
            zipCode: {
              type: 'string',
              description: 'ZIP code'
            },
            country: {
              type: 'string',
              description: 'Country'
            },
            contactPerson: {
              type: 'string',
              description: 'Contact person name'
            },
            contactEmail: {
              type: 'string',
              format: 'email',
              description: 'Contact email'
            },
            contactPhone: {
              type: 'string',
              description: 'Contact phone number'
            },
            createdAt: {
              type: 'string',
              format: 'date-time',
              description: 'Facility creation date'
            },
            updatedAt: {
              type: 'string',
              format: 'date-time',
              description: 'Facility last update date'
            }
          }
        },
        ComplianceCheck: {
          type: 'object',
          properties: {
            _id: {
              type: 'string',
              description: 'Compliance check ID'
            },
            regulationName: {
              type: 'string',
              description: 'Name of the regulation'
            },
            requirement: {
              type: 'string',
              description: 'Specific requirement being checked'
            },
            facilityId: {
              type: 'string',
              description: 'ID of the facility being checked'
            },
            facility: {
              $ref: '#/components/schemas/Facility',
              description: 'Facility details (populated)'
            },
            status: {
              type: 'string',
              enum: ['compliant', 'non_compliant', 'in_progress', 'not_applicable'],
              description: 'Compliance status'
            },
            lastCheckedDate: {
              type: 'string',
              format: 'date-time',
              description: 'Date of the last compliance check'
            },
            notes: {
              type: 'string',
              description: 'Additional notes about the compliance check'
            },
            createdAt: {
              type: 'string',
              format: 'date-time',
              description: 'Compliance check creation date'
            },
            updatedAt: {
              type: 'string',
              format: 'date-time',
              description: 'Compliance check last update date'
            }
          }
        },
        Role: {
          type: 'object',
          properties: {
            _id: {
              type: 'string',
              description: 'Role ID'
            },
            name: {
              type: 'string',
              enum: ['admin', 'compliance_officer', 'auditor', 'facility_manager', 'user'],
              description: 'Role name'
            },
            description: {
              type: 'string',
              description: 'Role description'
            },
            permissions: {
              type: 'array',
              items: {
                type: 'string'
              },
              description: 'List of permissions for this role'
            },
            createdAt: {
              type: 'string',
              format: 'date-time',
              description: 'Role creation date'
            },
            updatedAt: {
              type: 'string',
              format: 'date-time',
              description: 'Role last update date'
            }
          }
        }
      }
    },
    tags: [
      {
        name: 'Auth',
        description: 'Authentication endpoints'
      },
      {
        name: 'Users',
        description: 'User management endpoints'
      },
      {
        name: 'Compliance',
        description: 'Compliance check management endpoints'
      },
      {
        name: 'Roles',
        description: 'Role management endpoints'
      }
    ],
    paths: {
      '/auth/register': {
        post: {
          summary: 'Register a new user',
          tags: ['Auth'],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['name', 'email', 'password'],
                  properties: {
                    name: {
                      type: 'string',
                      description: 'User name'
                    },
                    email: {
                      type: 'string',
                      format: 'email',
                      description: 'User email'
                    },
                    password: {
                      type: 'string',
                      format: 'password',
                      description: 'User password'
                    }
                  }
                }
              }
            }
          },
          responses: {
            '201': {
              description: 'User registered successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            type: 'object',
                            properties: {
                              user: {
                                $ref: '#/components/schemas/User'
                              },
                              token: {
                                type: 'string',
                                description: 'JWT token'
                              }
                            }
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '400': {
              description: 'Registration failed',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        }
      },
      '/auth/login': {
        post: {
          summary: 'Login user',
          tags: ['Auth'],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['email', 'password'],
                  properties: {
                    email: {
                      type: 'string',
                      format: 'email',
                      description: 'User email'
                    },
                    password: {
                      type: 'string',
                      format: 'password',
                      description: 'User password'
                    }
                  }
                }
              }
            }
          },
          responses: {
            '200': {
              description: 'Login successful',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            type: 'object',
                            properties: {
                              user: {
                                $ref: '#/components/schemas/User'
                              },
                              token: {
                                type: 'string',
                                description: 'JWT token'
                              }
                            }
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '401': {
              description: 'Invalid credentials',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '403': {
              description: 'Email not verified',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        }
      },
      '/auth/verify-email': {
        post: {
          summary: 'Verify user email with verification code',
          tags: ['Auth'],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['email', 'code'],
                  properties: {
                    email: {
                      type: 'string',
                      format: 'email',
                      description: 'User email'
                    },
                    code: {
                      type: 'string',
                      minLength: 6,
                      maxLength: 6,
                      description: '6-digit verification code'
                    }
                  }
                }
              }
            }
          },
          responses: {
            '200': {
              description: 'Email verified successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            $ref: '#/components/schemas/VerificationResponse'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '400': {
              description: 'Invalid verification code',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '404': {
              description: 'User not found',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        }
      },
      '/auth/resend-verification': {
        post: {
          summary: 'Resend verification code to user email',
          tags: ['Auth'],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['email'],
                  properties: {
                    email: {
                      type: 'string',
                      format: 'email',
                      description: 'User email'
                    }
                  }
                }
              }
            }
          },
          responses: {
            '200': {
              description: 'Verification code sent successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            $ref: '#/components/schemas/VerificationResponse'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '404': {
              description: 'User not found',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        }
      },
      '/users': {
        get: {
          summary: 'Get all users',
          tags: ['Users'],
          security: [{ bearerAuth: [] }],
          responses: {
            '200': {
              description: 'Users retrieved successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            type: 'array',
                            items: {
                              $ref: '#/components/schemas/User'
                            }
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        },
        post: {
          summary: 'Create a new user',
          tags: ['Users'],
          security: [{ bearerAuth: [] }],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['name'],
                  properties: {
                    name: {
                      type: 'string',
                      description: 'User name'
                    }
                  }
                }
              }
            }
          },
          responses: {
            '201': {
              description: 'User created successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            $ref: '#/components/schemas/User'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '400': {
              description: 'Invalid input',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        }
      },
      '/users/{id}': {
        get: {
          summary: 'Get user by ID',
          tags: ['Users'],
          security: [{ bearerAuth: [] }],
          parameters: [
            {
              in: 'path',
              name: 'id',
              required: true,
              schema: {
                type: 'string'
              },
              description: 'User ID'
            }
          ],
          responses: {
            '200': {
              description: 'User retrieved successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            $ref: '#/components/schemas/User'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '404': {
              description: 'User not found',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        }
      },
      '/compliance': {
        get: {
          summary: 'Get all compliance checks',
          tags: ['Compliance'],
          security: [{ bearerAuth: [] }],
          parameters: [
            {
              in: 'query',
              name: 'facilityId',
              schema: {
                type: 'string'
              },
              description: 'Filter compliance checks by facility ID'
            }
          ],
          responses: {
            '200': {
              description: 'Compliance checks retrieved successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            type: 'array',
                            items: {
                              $ref: '#/components/schemas/ComplianceCheck'
                            }
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        },
        post: {
          summary: 'Create a new compliance check',
          tags: ['Compliance'],
          security: [{ bearerAuth: [] }],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['regulationName', 'requirement', 'facilityId'],
                  properties: {
                    regulationName: {
                      type: 'string',
                      description: 'Name of the regulation'
                    },
                    requirement: {
                      type: 'string',
                      description: 'Specific requirement being checked'
                    },
                    facilityId: {
                      type: 'string',
                      description: 'ID of the facility being checked'
                    },
                    status: {
                      type: 'string',
                      enum: ['compliant', 'non_compliant', 'in_progress', 'not_applicable'],
                      description: 'Compliance status'
                    },
                    notes: {
                      type: 'string',
                      description: 'Additional notes about the compliance check'
                    }
                  }
                }
              }
            }
          },
          responses: {
            '201': {
              description: 'Compliance check created successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            $ref: '#/components/schemas/ComplianceCheck'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '400': {
              description: 'Invalid input',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        }
      },
      '/compliance/{id}': {
        get: {
          summary: 'Get compliance check by ID',
          tags: ['Compliance'],
          security: [{ bearerAuth: [] }],
          parameters: [
            {
              in: 'path',
              name: 'id',
              required: true,
              schema: {
                type: 'string'
              },
              description: 'Compliance check ID'
            }
          ],
          responses: {
            '200': {
              description: 'Compliance check retrieved successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            $ref: '#/components/schemas/ComplianceCheck'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '404': {
              description: 'Compliance check not found',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        },
        put: {
          summary: 'Update a compliance check',
          tags: ['Compliance'],
          security: [{ bearerAuth: [] }],
          parameters: [
            {
              in: 'path',
              name: 'id',
              required: true,
              schema: {
                type: 'string'
              },
              description: 'Compliance check ID'
            }
          ],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    regulationName: {
                      type: 'string',
                      description: 'Name of the regulation'
                    },
                    requirement: {
                      type: 'string',
                      description: 'Specific requirement being checked'
                    },
                    facilityId: {
                      type: 'string',
                      description: 'ID of the facility being checked'
                    },
                    status: {
                      type: 'string',
                      enum: ['compliant', 'non_compliant', 'in_progress', 'not_applicable'],
                      description: 'Compliance status'
                    },
                    notes: {
                      type: 'string',
                      description: 'Additional notes about the compliance check'
                    }
                  }
                }
              }
            }
          },
          responses: {
            '200': {
              description: 'Compliance check updated successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            $ref: '#/components/schemas/ComplianceCheck'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '400': {
              description: 'Invalid input',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '404': {
              description: 'Compliance check not found',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        },
        delete: {
          summary: 'Delete a compliance check',
          tags: ['Compliance'],
          security: [{ bearerAuth: [] }],
          parameters: [
            {
              in: 'path',
              name: 'id',
              required: true,
              schema: {
                type: 'string'
              },
              description: 'Compliance check ID'
            }
          ],
          responses: {
            '200': {
              description: 'Compliance check deleted successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            type: 'null'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '404': {
              description: 'Compliance check not found',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        }
      },
      '/roles': {
        get: {
          summary: 'Get all roles',
          tags: ['Roles'],
          security: [{ bearerAuth: [] }],
          responses: {
            '200': {
              description: 'Roles retrieved successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            type: 'array',
                            items: {
                              $ref: '#/components/schemas/Role'
                            }
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '403': {
              description: 'Forbidden',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        },
        post: {
          summary: 'Create a new role',
          tags: ['Roles'],
          security: [{ bearerAuth: [] }],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['name', 'description', 'permissions'],
                  properties: {
                    name: {
                      type: 'string',
                      enum: ['admin', 'compliance_officer', 'auditor', 'facility_manager', 'user'],
                      description: 'Role name'
                    },
                    description: {
                      type: 'string',
                      description: 'Role description'
                    },
                    permissions: {
                      type: 'array',
                      items: {
                        type: 'string'
                      },
                      description: 'List of permissions for this role'
                    }
                  }
                }
              }
            }
          },
          responses: {
            '201': {
              description: 'Role created successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            $ref: '#/components/schemas/Role'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '400': {
              description: 'Invalid input',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '403': {
              description: 'Forbidden',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        }
      },
      '/roles/{name}': {
        get: {
          summary: 'Get role by name',
          tags: ['Roles'],
          security: [{ bearerAuth: [] }],
          parameters: [
            {
              in: 'path',
              name: 'name',
              required: true,
              schema: {
                type: 'string',
                enum: ['admin', 'compliance_officer', 'auditor', 'facility_manager', 'user']
              },
              description: 'Role name'
            }
          ],
          responses: {
            '200': {
              description: 'Role retrieved successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            $ref: '#/components/schemas/Role'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '403': {
              description: 'Forbidden',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '404': {
              description: 'Role not found',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        },
        put: {
          summary: 'Update a role',
          tags: ['Roles'],
          security: [{ bearerAuth: [] }],
          parameters: [
            {
              in: 'path',
              name: 'name',
              required: true,
              schema: {
                type: 'string',
                enum: ['admin', 'compliance_officer', 'auditor', 'facility_manager', 'user']
              },
              description: 'Role name'
            }
          ],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    description: {
                      type: 'string',
                      description: 'Role description'
                    },
                    permissions: {
                      type: 'array',
                      items: {
                        type: 'string'
                      },
                      description: 'List of permissions for this role'
                    }
                  }
                }
              }
            }
          },
          responses: {
            '200': {
              description: 'Role updated successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            $ref: '#/components/schemas/Role'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '400': {
              description: 'Invalid input',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '403': {
              description: 'Forbidden',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '404': {
              description: 'Role not found',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        },
        delete: {
          summary: 'Delete a role',
          tags: ['Roles'],
          security: [{ bearerAuth: [] }],
          parameters: [
            {
              in: 'path',
              name: 'name',
              required: true,
              schema: {
                type: 'string',
                enum: ['admin', 'compliance_officer', 'auditor', 'facility_manager', 'user']
              },
              description: 'Role name'
            }
          ],
          responses: {
            '200': {
              description: 'Role deleted successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          data: {
                            type: 'null'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '403': {
              description: 'Forbidden',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '404': {
              description: 'Role not found',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        }
      },
      '/roles/initialize': {
        post: {
          summary: 'Initialize default roles',
          tags: ['Roles'],
          security: [{ bearerAuth: [] }],
          responses: {
            '200': {
              description: 'Default roles initialized successfully',
              content: {
                'application/json': {
                  schema: {
                    allOf: [
                      { $ref: '#/components/schemas/ApiResponse' },
                      {
                        properties: {
                          message: {
                            type: 'string',
                            description: 'Success message'
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            '401': {
              description: 'Unauthorized',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '403': {
              description: 'Forbidden',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            },
            '500': {
              description: 'Server error',
              content: {
                'application/json': {
                  schema: {
                    $ref: '#/components/schemas/ApiResponse'
                  }
                }
              }
            }
          }
        }
      }
    }
  },
  apis: []
};

export const swaggerSpec = swaggerJsdoc(options); 