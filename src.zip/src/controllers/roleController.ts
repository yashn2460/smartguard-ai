import { Request, Response, NextFunction } from 'express';
import { RoleService } from '../services/roleService';
import { RoleType } from '../models/Role';

export class RoleController {
  private roleService: RoleService;

  constructor() {
    this.roleService = new RoleService();
  }

  /**
   * Get all roles
   */
  public getRoles = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const roles = await this.roleService.getRoles();
      
      res.status(200).json({
        success: true,
        data: roles
      });
    } catch (error) {
      next(error);
    }
  };

  /**
   * Get a role by name
   */
  public getRoleByName = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { name } = req.params;
      const role = await this.roleService.getRoleByName(name as RoleType);
      
      res.status(200).json({
        success: true,
        data: role
      });
    } catch (error) {
      next(error);
    }
  };

  /**
   * Create a new role
   */
  public createRole = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const role = await this.roleService.createRole(req.body);
      
      res.status(201).json({
        success: true,
        data: role
      });
    } catch (error) {
      next(error);
    }
  };

  /**
   * Update a role
   */
  public updateRole = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { name } = req.params;
      const role = await this.roleService.updateRole(name as RoleType, req.body);
      
      res.status(200).json({
        success: true,
        data: role
      });
    } catch (error) {
      next(error);
    }
  };

  /**
   * Delete a role
   */
  public deleteRole = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { name } = req.params;
      await this.roleService.deleteRole(name as RoleType);
      
      res.status(200).json({
        success: true,
        data: null
      });
    } catch (error) {
      next(error);
    }
  };

  /**
   * Initialize default roles
   */
  public initializeDefaultRoles = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      await this.roleService.initializeDefaultRoles();
      
      res.status(200).json({
        success: true,
        message: 'Default roles initialized successfully'
      });
    } catch (error) {
      next(error);
    }
  };
} 