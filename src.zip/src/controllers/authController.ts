import { Request, Response } from 'express';
import { AuthService } from '../services/authService';
import { ApiResponse } from '../interfaces/apiResponse';
import { ApiError } from '../utils/apiError';

export class AuthController {
  private authService: AuthService;

  constructor() {
    this.authService = new AuthService();
  }

  public register = async (req: Request, res: Response): Promise<void> => {
    try {
      const { user, token } = await this.authService.register(req.body);
      const response: ApiResponse = {
        success: true,
        data: { user, token },
        message: 'User registered successfully. Please check your email for verification code.',
        statusCode: 201
      };
      res.status(201).json(response);
    } catch (error) {
      console.log(error);
      if (error instanceof ApiError) {
        const response: ApiResponse = {
          success: false,
          error: error.message,
          message: 'Registration failed',
          statusCode: error.statusCode
        };
        
        res.status(error.statusCode).json(response);
      } else {
        const response: ApiResponse = {
          success: false,
          error: 'An unexpected error occurred',
          message: 'Registration failed',
          statusCode: 500
        };
        res.status(500).json(response);
      }
    }
  };

  public login = async (req: Request, res: Response): Promise<void> => {
    try {
      const { email, password } = req.body;
      const { user, token } = await this.authService.login(email, password);
      const response: ApiResponse = {
        success: true,
        data: { user, token },
        message: 'Login successful',
        statusCode: 200
      };
      res.status(200).json(response);
    } catch (error) {
      if (error instanceof ApiError) {
        const response: ApiResponse = {
          success: false,
          error: error.message,
          message: 'Login failed',
          statusCode: error.statusCode
        };
        res.status(error.statusCode).json(response);
      } else {
        const response: ApiResponse = {
          success: false,
          error: 'An unexpected error occurred',
          message: 'Login failed',
          statusCode: 500
        };
        res.status(500).json(response);
      }
    }
  };

  public verifyEmail = async (req: Request, res: Response): Promise<void> => {
    try {
      const { email, code } = req.body;
      const result = await this.authService.verifyEmail(email, code);
      const response: ApiResponse = {
        success: true,
        data: result,
        message: 'Email verified successfully',
        statusCode: 200
      };
      res.status(200).json(response);
    } catch (error) {
      if (error instanceof ApiError) {
        const response: ApiResponse = {
          success: false,
          error: error.message,
          message: 'Email verification failed',
          statusCode: error.statusCode
        };
        res.status(error.statusCode).json(response);
      } else {
        const response: ApiResponse = {
          success: false,
          error: 'An unexpected error occurred',
          message: 'Email verification failed',
          statusCode: 500
        };
        res.status(500).json(response);
      }
    }
  };

  public resendVerificationCode = async (req: Request, res: Response): Promise<void> => {
    try {
      const { email } = req.body;
      const result = await this.authService.resendVerificationCode(email);
      const response: ApiResponse = {
        success: true,
        data: result,
        message: 'Verification code sent successfully',
        statusCode: 200
      };
      res.status(200).json(response);
    } catch (error) {
      if (error instanceof ApiError) {
        const response: ApiResponse = {
          success: false,
          error: error.message,
          message: 'Failed to resend verification code',
          statusCode: error.statusCode
        };
        res.status(error.statusCode).json(response);
      } else {
        const response: ApiResponse = {
          success: false,
          error: 'An unexpected error occurred',
          message: 'Failed to resend verification code',
          statusCode: 500
        };
        res.status(500).json(response);
      }
    }
  };
} 