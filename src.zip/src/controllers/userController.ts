import { Request, Response } from 'express';
import { UserService } from '../services/userService';
import { ApiResponse } from '../interfaces/apiResponse';

export class UserController {
  private userService: UserService;

  constructor() {
    this.userService = new UserService();
  }

  public createUser = async (req: Request, res: Response): Promise<void> => {
    try {
      const user = await this.userService.createUser(req.body);
      const response: ApiResponse = {
        success: true,
        data: user,
        message: 'User created successfully',
        statusCode: 201
      };
      res.status(201).json(response);
    } catch (error) {
      const response: ApiResponse = {
        success: false,
        error: error instanceof Error ? error.message : 'Error creating user',
        message: 'Failed to create user',
        statusCode: 400
      };
      res.status(400).json(response);
    }
  };

  public getUsers = async (req: Request, res: Response): Promise<void> => {
    try {
      const users = await this.userService.getUsers();
      const response: ApiResponse = {
        success: true,
        data: users,
        message: 'Users retrieved successfully',
        statusCode: 200
      };
      res.status(200).json(response);
    } catch (error) {
      const response: ApiResponse = {
        success: false,
        error: error instanceof Error ? error.message : 'Error fetching users',
        message: 'Failed to fetch users',
        statusCode: 500
      };
      res.status(500).json(response);
    }
  };

  public getUserById = async (req: Request, res: Response): Promise<void> => {
    try {
      const user = await this.userService.getUserById(req.params.id);
      if (!user) {
        const response: ApiResponse = {
          success: false,
          message: 'User not found',
          statusCode: 404
        };
        res.status(404).json(response);
        return;
      }
      const response: ApiResponse = {
        success: true,
        data: user,
        message: 'User retrieved successfully',
        statusCode: 200
      };
      res.status(200).json(response);
    } catch (error) {
      const response: ApiResponse = {
        success: false,
        error: error instanceof Error ? error.message : 'Error fetching user',
        message: 'Failed to fetch user',
        statusCode: 500
      };
      res.status(500).json(response);
    }
  };
} 