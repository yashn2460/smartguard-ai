import { Request, Response, NextFunction } from 'express';
import { ComplianceService } from '../services/complianceService';
import { ApiError } from '../utils/apiError';

export class ComplianceController {
  private complianceService: ComplianceService;

  constructor() {
    this.complianceService = new ComplianceService();
  }

  /**
   * Get all compliance checks
   */
  public getComplianceChecks = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { facilityId } = req.query;
      const complianceChecks = await this.complianceService.getComplianceChecks(facilityId as string);
      
      res.status(200).json({
        success: true,
        data: complianceChecks
      });
    } catch (error) {
      next(error);
    }
  };

  /**
   * Get a compliance check by ID
   */
  public getComplianceCheckById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const complianceCheck = await this.complianceService.getComplianceCheckById(id);
      
      res.status(200).json({
        success: true,
        data: complianceCheck
      });
    } catch (error) {
      next(error);
    }
  };

  /**
   * Create a new compliance check
   */
  public createComplianceCheck = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const complianceCheck = await this.complianceService.createComplianceCheck(req.body);
      
      res.status(201).json({
        success: true,
        data: complianceCheck
      });
    } catch (error) {
      next(error);
    }
  };

  /**
   * Update a compliance check
   */
  public updateComplianceCheck = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const complianceCheck = await this.complianceService.updateComplianceCheck(id, req.body);
      
      res.status(200).json({
        success: true,
        data: complianceCheck
      });
    } catch (error) {
      next(error);
    }
  };

  /**
   * Delete a compliance check
   */
  public deleteComplianceCheck = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      await this.complianceService.deleteComplianceCheck(id);
      
      res.status(200).json({
        success: true,
        data: null
      });
    } catch (error) {
      next(error);
    }
  };
} 