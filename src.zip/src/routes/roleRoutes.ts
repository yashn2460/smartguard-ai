import { Router } from 'express';
import { RoleController } from '../controllers/roleController';
import { validateRequest } from '../middleware/validateRequest';
import { createRoleSchema, updateRoleSchema } from '../schemas/roleSchema';
import { authenticate } from '../middleware/authenticate';
import { authorize } from '../middleware/authorize';
import { RoleType } from '../models/Role';

const router = Router();
const roleController = new RoleController();

// All role routes require authentication and admin role
router.use(authenticate, authorize([RoleType.ADMIN]));

router.get('/', roleController.getRoles);

router.get('/:name', roleController.getRoleByName);

router.post('/', validateRequest(createRoleSchema), roleController.createRole);

router.put('/:name', validateRequest(updateRoleSchema), roleController.updateRole);

router.delete('/:name', roleController.deleteRole);

// Special route to initialize default roles (admin only)
router.post('/initialize', roleController.initializeDefaultRoles);

export default router; 