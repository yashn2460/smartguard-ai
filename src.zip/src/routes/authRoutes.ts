import { Router } from 'express';
import { AuthController } from '../controllers/authController';
import { validateRequest } from '../middleware/validation';
import { 
  loginSchema, 
  registerSchema, 
  verifyEmailSchema, 
  resendVerificationSchema 
} from '../validations/authValidation';

const router = Router();
const authController = new AuthController();

// Auth routes
router.post('/register', validateRequest(registerSchema), authController.register);
router.post('/login', validateRequest(loginSchema), authController.login);
router.post('/verify-email', validateRequest(verifyEmailSchema), authController.verifyEmail);
router.post('/resend-verification', validateRequest(resendVerificationSchema), authController.resendVerificationCode);

export default router; 