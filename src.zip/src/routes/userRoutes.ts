import { Router } from 'express';
import { UserController } from '../controllers/userController';
import { validateRequest } from '../middleware/validation';
import { createUserSchema, userIdParamSchema } from '../validations/userValidation';

const router = Router();
const userController = new UserController();

// User routes
router.post('/', validateRequest(createUserSchema), userController.createUser);
router.get('/', userController.getUsers);
router.get('/:id', validateRequest(userIdParamSchema, 'params'), userController.getUserById);

export default router; 