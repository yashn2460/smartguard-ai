import { Router } from 'express';
import { ComplianceController } from '../controllers/complianceController';
import { validateRequest } from '../middleware/validateRequest';
import { createComplianceCheckSchema, updateComplianceCheckSchema } from '../schemas/complianceSchema';
import { RoleType } from '../models/Role';
import { authenticate } from '../middleware/authenticate';
import { authorize } from '../middleware/authorize';


const router = Router();
const complianceController = new ComplianceController();

// All role routes require authentication and compliance officer role
router.use(authenticate, authorize([RoleType.COMPLIANCE_OFFICER]));
router.get('/', complianceController.getComplianceChecks);

router.get('/:id', complianceController.getComplianceCheckById);

router.post('/', validateRequest(createComplianceCheckSchema), complianceController.createComplianceCheck);

router.put('/:id', validateRequest(updateComplianceCheckSchema), complianceController.updateComplianceCheck);

router.delete('/:id', complianceController.deleteComplianceCheck);

export default router; 