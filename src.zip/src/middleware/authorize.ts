import { Request, Response, NextFunction } from 'express';
import { RoleType } from '../models/Role';
import { ApiError } from '../utils/apiError';

export const authorize = (roles: RoleType[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    try {
      // Check if user exists (should be attached by authenticate middleware)
      if (!req.user) {
        throw new ApiError('Authentication required', 401);
      }
      
      // Check if user has required role
      if (!roles.includes(req.user.role)) {
        throw new ApiError('You do not have permission to perform this action', 403);
      }
      
      next();
    } catch (error) {
      next(error);
    }
  };
}; 