import { Request, Response, NextFunction } from 'express';
import { ApiResponse } from '../interfaces/apiResponse';

export const errorHandler = (
  err: Error,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  console.error(err.stack);

  const response: ApiResponse = {
    success: false,
    error: err.message,
    message: 'Internal server error',
    statusCode: 500
  };

  res.status(500).json(response);
}; 