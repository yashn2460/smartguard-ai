import { Request, Response, NextFunction } from 'express';
import Joi from 'joi';
import { ApiError } from '../utils/apiError';

/**
 * Middleware to validate request data against a Joi schema
 * @param schema Joi schema to validate against
 * @param property Property of the request to validate (body, query, params)
 */
export const validateRequest = (schema: Joi.ObjectSchema, property: 'body' | 'query' | 'params' = 'body') => {
  return (req: Request, res: Response, next: NextFunction) => {
    const { error } = schema.validate(req[property], { abortEarly: false });
    
    if (!error) {
      next();
    } else {
      const errorMessage = error.details.map(detail => detail.message).join(', ');
      next(new ApiError(errorMessage, 400));
    }
  };
}; 