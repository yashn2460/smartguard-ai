import mongoose, { Document, Schema } from 'mongoose';

export enum ComplianceStatus {
  COMPLIANT = 'compliant',
  NON_COMPLIANT = 'non_compliant',
  IN_PROGRESS = 'in_progress',
  NOT_APPLICABLE = 'not_applicable'
}

export interface IComplianceCheck extends Document {
  regulationName: string;
  requirement: string;
  facilityId: mongoose.Types.ObjectId;
  status: ComplianceStatus;
  lastCheckedDate: Date;
  notes: string;
  createdAt: Date;
  updatedAt: Date;
}

const complianceCheckSchema = new Schema<IComplianceCheck>(
  {
    regulationName: {
      type: String,
      required: true,
      trim: true,
    },
    requirement: {
      type: String,
      required: true,
      trim: true,
    },
    facilityId: {
      type: Schema.Types.ObjectId,
      ref: 'Facility',
      required: true,
    },
    status: {
      type: String,
      enum: Object.values(ComplianceStatus),
      default: ComplianceStatus.IN_PROGRESS,
    },
    lastCheckedDate: {
      type: Date,
      default: Date.now,
    },
    notes: {
      type: String,
      trim: true,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

export const ComplianceCheck = mongoose.model<IComplianceCheck>('ComplianceCheck', complianceCheckSchema); 