import { Document, Schema, model } from 'mongoose';
import { RoleType } from './Role';

export interface IUser extends Document {
  name: string;
  email: string;
  password: string;
  isEmailVerified: boolean;
  verificationCode?: string;
  verificationCodeExpires?: Date;
  role: RoleType;
  createdAt: Date;
  updatedAt: Date;
}

const userSchema = new Schema<IUser>(
  {
    name: {
      type: String,
      required: true,
      trim: true
    },
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true
    },
    role: {
      type: String,
      enum: Object.values(RoleType),
      default: RoleType.USER
    }
  },
  {
    timestamps: true
  }
);

export const User = model<IUser>('User', userSchema); 