import { Document, Schema, model } from 'mongoose';

export enum RoleType {
  ADMIN = 'admin',
  COMPLIANCE_OFFICER = 'compliance_officer',
  AUDITOR = 'auditor',
  FACILITY_MANAGER = 'facility_manager',
  USER = 'user'
}

export interface IRole extends Document {
  name: RoleType;
  description: string;
  permissions: string[];
  createdAt: Date;
  updatedAt: Date;
}

const roleSchema = new Schema<IRole>(
  {
    name: {
      type: String,
      enum: Object.values(RoleType),
      required: true,
      unique: true,
      trim: true
    },
    description: {
      type: String,
      required: true,
      trim: true
    },
    permissions: [{
      type: String,
      trim: true
    }]
  },
  {
    timestamps: true
  }
);

export const Role = model<IRole>('Role', roleSchema); 